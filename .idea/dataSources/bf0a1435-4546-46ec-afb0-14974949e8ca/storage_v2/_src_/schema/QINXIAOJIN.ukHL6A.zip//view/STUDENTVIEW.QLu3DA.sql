create view STUDENTVIEW as
select stuid,studate,stuname,pwd,sex,address from student
where stuname is not null
/

