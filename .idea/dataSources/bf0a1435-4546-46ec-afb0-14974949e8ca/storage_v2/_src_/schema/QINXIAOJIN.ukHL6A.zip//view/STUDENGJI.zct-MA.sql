create view STUDENGJI as
select s.stuid,s.stuname,score,d.dengji from student s,dengji d
where s.score >=d.minscore and s.score<=d.maxscore
/

