create function test_fun
 return date
 is mydate date;
 begin
 select sysdate into mydate from dual;
 dbms_output.put_line('日期：'||mydate);
 return mydate;
 end;
/

