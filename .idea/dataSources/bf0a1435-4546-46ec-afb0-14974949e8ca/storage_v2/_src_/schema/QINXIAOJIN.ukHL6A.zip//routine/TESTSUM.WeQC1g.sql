create function testsum(
 sid number,sno out number)
 return number is ssum number;
 begin
 select sum(score),count(*) into ssum,sno from student where stuid>30;
 dbms_output.put_line('统计'||ssum||' '||sno);
 return ssum;
 end;
/

